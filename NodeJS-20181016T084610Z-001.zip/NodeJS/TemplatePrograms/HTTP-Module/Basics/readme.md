# Files

├── app.js - *Simple server program. Handles multiple url paths. Shows usage of status code*  
├── http-hello.js  - *Illustrates use of http module to respond to request*  
├── http-listen.js - *Listens for connection and prints message on connection*   
├── page.html - *Static html page*  
└── readme.md  
  
