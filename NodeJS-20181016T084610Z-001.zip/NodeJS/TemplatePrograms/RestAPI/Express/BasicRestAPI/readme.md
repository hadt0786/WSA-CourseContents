## Steps to run the application


>npm install
node index.js