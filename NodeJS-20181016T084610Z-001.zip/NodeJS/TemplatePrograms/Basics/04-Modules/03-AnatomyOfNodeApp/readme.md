#Print jokes randomly every few seconds.
##This app shows an example of writing structured code. Modules are created to organize the code.

```
Run: node index.js
```  
  
#Files  
├── index.js  
├── lib  
│   ├── jokes  
│   │   ├── index.js  
│   │   └── jokes.txt  
│   └── math.js  
├── readme.html  
└── readme.md  
