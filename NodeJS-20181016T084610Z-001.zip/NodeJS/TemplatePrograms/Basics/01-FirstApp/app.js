/* Title: Hello World Program
 * Description: Simple program to print a message
 * Run: node app.js
 */

function sayHello(name) {
    console.log("Hello " + name);
}

sayHello('Mubeen');
