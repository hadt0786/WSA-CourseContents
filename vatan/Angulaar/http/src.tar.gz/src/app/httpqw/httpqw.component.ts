import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-httpqw',
  templateUrl: './httpqw.component.html',
  styleUrls: ['./httpqw.component.css']
})
export class HttpqwComponent implements OnInit {

  myPosts: any[];
  private myURL ='https://jsonplaceholder.typicode.com/posts';
  constructor(private myHttp: Http) { 
    myHttp.get(this.myURL).subscribe(response =>{
      console.log(response.json());
      this.myPosts = response.json();
    })
  }

  ngOnInit() {
  }

}
