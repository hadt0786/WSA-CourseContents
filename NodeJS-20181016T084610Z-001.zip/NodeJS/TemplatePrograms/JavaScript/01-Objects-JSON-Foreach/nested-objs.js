
var emp = {
    "employee" : {"name": "John", "age": 25}
};

var dept = {
    "name" : emp
};

console.log(dept);