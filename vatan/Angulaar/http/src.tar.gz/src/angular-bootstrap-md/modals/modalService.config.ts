export const msConfig = {
    serviceInstance: new Object()
}