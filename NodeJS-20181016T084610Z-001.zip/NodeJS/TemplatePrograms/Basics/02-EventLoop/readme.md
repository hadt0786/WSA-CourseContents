#Files

├── event-loop.js - *Program illustrating timer triggered callback*
├── call-stack.js - *Program illustrating call stack*
└── adv-event-loop.js - *Program illustrating timer triggered callback. Emphasis on event loop, Synchronous vs Asynchronous functions*
