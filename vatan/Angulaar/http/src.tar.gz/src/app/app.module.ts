import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HttpqwComponent } from './httpqw/httpqw.component';
import { MDBBootstrapModule } from '../angular-bootstrap-md';

@NgModule({
  declarations: [
    AppComponent,
    HttpqwComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    MDBBootstrapModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
