Illustration of how we can include modules/files in node
In index.js we include logger.js using the require function
Run: node index.js
