# Demonstrates use of underscore module from NPM

 + Initialize ***package.json*** file
```
Run: npm init
or
Run: npm init --yes
```

 + Install underscore from NPM repo
  ```
  Run: npm install underscore
  ```
This should download underscore from NPM into ***node_modules*** directory.
Also check the **depedencies** property in *package.json* file
