export { MdbIconComponent } from './icon.component';
export { IconsModule } from './icon.module';
