//Define an interface
export interface Course {
    name?: string,
    author?: string,
    price?: number,
    hide?: boolean
}